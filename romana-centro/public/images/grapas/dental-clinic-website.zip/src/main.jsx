import React from "react"
import ReactDOM from "react-dom/client"
import App from "./App.jsx"
import "./index.css"

// Ensure DOM is loaded before rendering
const renderApp = () => {
  const rootElement = document.getElementById("root")

  if (!rootElement) {
    console.error("Root element not found. Make sure there's a div with id='root' in your HTML.")
    return
  }

  try {
    const root = ReactDOM.createRoot(rootElement)
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>,
    )
  } catch (error) {
    console.error("Error rendering the app:", error)
  }
}

// Check if DOM is already loaded
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", renderApp)
} else {
  renderApp()
}
