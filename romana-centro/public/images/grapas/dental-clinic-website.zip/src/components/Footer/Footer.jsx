import { Smile, Facebook, Instagram, Twitter, Linkedin } from "lucide-react"
import styles from "./Footer.module.css"

const Footer = () => {
  const currentYear = new Date().getFullYear()

  return (
    <footer className={styles.footer}>
      <div className="container">
        <div className={styles.footerContent}>
          <div className={styles.footerBrand}>
            <a href="#hero" className={styles.brandLogo}>
              <Smile className={styles.logoIcon} aria-hidden="true" />
              <span>Miami Beach Smiles</span>
            </a>
            <p className={styles.brandDescription}>
              Comprehensive Family, Cosmetic & Implant Dentistry. Experience the gold standard for modern, premium
              dental care in Miami Beach.
            </p>
            <div className={styles.socialLinks}>
              <a
                href="https://facebook.com/miamibeachsmiles"
                className={styles.socialLink}
                aria-label="Follow us on Facebook"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Facebook size={18} />
              </a>
              <a
                href="https://instagram.com/miamibeachsmiles"
                className={styles.socialLink}
                aria-label="Follow us on Instagram"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Instagram size={18} />
              </a>
              <a
                href="https://twitter.com/miamibeachsmiles"
                className={styles.socialLink}
                aria-label="Follow us on Twitter"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Twitter size={18} />
              </a>
              <a
                href="https://linkedin.com/company/miamibeachsmiles"
                className={styles.socialLink}
                aria-label="Connect with us on LinkedIn"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Linkedin size={18} />
              </a>
            </div>
          </div>

          <div className={styles.footerSection}>
            <h4>Services</h4>
            <ul className={styles.footerLinks}>
              <li>
                <a href="#services">General Dentistry</a>
              </li>
              <li>
                <a href="#services">Cosmetic Dentistry</a>
              </li>
              <li>
                <a href="#services">Restorative Dentistry</a>
              </li>
              <li>
                <a href="#services">Invisalign</a>
              </li>
              <li>
                <a href="#services">Dental Implants</a>
              </li>
              <li>
                <a href="#services">Emergency Care</a>
              </li>
            </ul>
          </div>

          <div className={styles.footerSection}>
            <h4>Patient Info</h4>
            <ul className={styles.footerLinks}>
              <li>
                <a href="#contact">Patient Information</a>
              </li>
              <li>
                <a href="#contact">Patient Education</a>
              </li>
              <li>
                <a href="#contact">Insurance & Financing</a>
              </li>
              <li>
                <a href="#contact">Frequently Asked Questions</a>
              </li>
              <li>
                <a href="#contact">Office Tour</a>
              </li>
            </ul>
          </div>

          <div className={styles.footerSection}>
            <h4>Contact</h4>
            <ul className={styles.footerLinks}>
              <li>
                <a href="tel:(305)534-2526">(305) 534-2526</a>
              </li>
              <li>
                <a href="mailto:info@miamibeachsmiles.com">info@miamibeachsmiles.com</a>
              </li>
              <li>
                1688 Meridian Ave, Suite 414
                <br />
                Miami Beach, FL 33139
              </li>
            </ul>
          </div>
        </div>

        <div className={styles.footerBottom}>
          <p className={styles.copyright}>© {currentYear} Miami Beach Smiles. All rights reserved.</p>
          <ul className={styles.footerBottomLinks}>
            <li>
              <a href="/privacy">Privacy Policy</a>
            </li>
            <li>
              <a href="/terms">Terms of Service</a>
            </li>
            <li>
              <a href="/accessibility">Accessibility</a>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  )
}

export default Footer
