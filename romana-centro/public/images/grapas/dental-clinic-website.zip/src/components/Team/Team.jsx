import { Mail, Linkedin } from "lucide-react"
import styles from "./Team.module.css"

const Team = () => {
  const doctors = [
    {
      id: 1,
      name: "Dr. Tommy Gaertner",
      specialty: "General & Cosmetic Dentistry",
      image: "/placeholder.svg?height=350&width=300",
      bio: "With his fresh perspective, valued experience, and background, Dr. Gaertner has the privilege of treating all patients in his Miami Beach office like family. He is passionate about dentistry and continues his education to guarantee dental excellence.",
      credentials: [
        "DDS - University of Florida",
        "Member of American Dental Association",
        "Certified in Invisalign Treatment",
        "15+ years of experience",
      ],
    },
    {
      id: 2,
      name: "Dr. Sarah Johnson",
      specialty: "Orthodontics & Periodontics",
      image: "/placeholder.svg?height=350&width=300",
      bio: "Dr. Johnson specializes in orthodontics and periodontal care, bringing advanced techniques and personalized treatment plans to help patients achieve optimal oral health and beautiful smiles.",
      credentials: [
        "DDS - Harvard School of Dental Medicine",
        "Specialty in Orthodontics",
        "Board Certified Periodontist",
        "12+ years of experience",
      ],
    },
    {
      id: 3,
      name: "Dr. Michael Rodriguez",
      specialty: "Oral Surgery & Implants",
      image: "/placeholder.svg?height=350&width=300",
      bio: "Dr. Rodriguez is our oral surgery specialist, focusing on dental implants and complex surgical procedures. His expertise ensures safe and effective treatment for all surgical dental needs.",
      credentials: [
        "DDS - NYU College of Dentistry",
        "Oral & Maxillofacial Surgery Residency",
        "Certified Implant Specialist",
        "10+ years of experience",
      ],
    },
  ]

  return (
    <section id="team" className={styles.team}>
      <div className="container">
        <div className={styles.teamHeader}>
          <p className={styles.teamSubtitle}>Meet Our Team</p>
          <h2 className={styles.teamTitle}>
            Expert Dental Professionals
            <br />
            Dedicated to Your Care
          </h2>
          <p className={styles.teamDescription}>
            Our experienced team of dental professionals is committed to providing exceptional care with a gentle touch
            and personalized treatment plans.
          </p>
        </div>

        <div className={styles.teamGrid}>
          {doctors.map((doctor) => (
            <article key={doctor.id} className={styles.doctorCard}>
              <img
                src={doctor.image || "/placeholder.svg"}
                alt={`Portrait of ${doctor.name}`}
                className={styles.doctorImage}
                loading="lazy"
              />
              <div className={styles.doctorInfo}>
                <h3 className={styles.doctorName}>{doctor.name}</h3>
                <p className={styles.doctorSpecialty}>{doctor.specialty}</p>
                <p className={styles.doctorBio}>{doctor.bio}</p>
                <ul className={styles.doctorCredentials}>
                  {doctor.credentials.map((credential, index) => (
                    <li key={index}>{credential}</li>
                  ))}
                </ul>
                <div className={styles.socialLinks}>
                  <a
                    href={`mailto:${doctor.name.toLowerCase().replace(" ", ".")}@miamibeachsmiles.com`}
                    className={styles.socialLink}
                    aria-label={`Email ${doctor.name}`}
                  >
                    <Mail size={18} />
                  </a>
                  <a href="#" className={styles.socialLink} aria-label={`${doctor.name} LinkedIn profile`}>
                    <Linkedin size={18} />
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}

export default Team
