import { Smile, Sparkles, Shield, Zap, ArrowRight } from "lucide-react"
import styles from "./Services.module.css"

const Services = () => {
  const services = [
    {
      id: 1,
      title: "General Dentistry",
      description:
        "Comprehensive dental care including checkups, cleanings, and preventive treatments to maintain optimal oral health.",
      features: ["Dental Checkups & Cleanings", "Sedation Dentistry", "Root Canal Treatment", "Emergency Dentistry"],
      icon: Shield,
      image: "/placeholder.svg?height=250&width=400",
    },
    {
      id: 2,
      title: "Cosmetic Dentistry",
      description:
        "Transform your smile with our advanced cosmetic procedures designed to enhance the beauty of your teeth.",
      features: ["Porcelain Dental Veneers", "Smile Makeover", "Teeth Whitening", "Dental Bonding"],
      icon: Sparkles,
      image: "/placeholder.svg?height=250&width=400",
    },
    {
      id: 3,
      title: "Restorative Dentistry",
      description:
        "Restore function and aesthetics to damaged or missing teeth with our comprehensive restorative solutions.",
      features: ["Dental Implants", "Crowns and Bridges", "Dentures and Partial Dentures", "Root Canal Treatment"],
      icon: Zap,
      image: "/placeholder.svg?height=250&width=400",
    },
    {
      id: 4,
      title: "Invisalign",
      description: "Straighten your teeth discreetly with clear aligners that are virtually invisible and removable.",
      features: ["Clear Aligners", "Personalized Treatment Plans", "Comfortable & Removable", "Faster Results"],
      icon: Smile,
      image: "/placeholder.svg?height=250&width=400",
    },
  ]

  return (
    <section id="services" className={styles.services}>
      <div className="container">
        <div className={styles.servicesHeader}>
          <p className={styles.servicesSubtitle}>Our Services</p>
          <h2 className={styles.servicesTitle}>
            Comprehensive Dental Care
            <br />
            for Every Need
          </h2>
          <p className={styles.servicesDescription}>
            From routine cleanings to complex restorative procedures, we offer a full range of dental services using the
            latest technology and techniques.
          </p>
        </div>

        <div className={styles.servicesGrid}>
          {services.map((service) => {
            const IconComponent = service.icon
            return (
              <article key={service.id} className={styles.serviceCard}>
                <img
                  src={service.image || "/placeholder.svg"}
                  alt={`${service.title} treatment`}
                  className={styles.serviceImage}
                  loading="lazy"
                />
                <div className={styles.serviceContent}>
                  <IconComponent className={styles.serviceIcon} aria-hidden="true" />
                  <h3 className={styles.serviceTitle}>{service.title}</h3>
                  <p className={styles.serviceDescription}>{service.description}</p>
                  <ul className={styles.serviceFeatures}>
                    {service.features.map((feature, index) => (
                      <li key={index}>{feature}</li>
                    ))}
                  </ul>
                  <a href="#contact" className={styles.learnMoreButton}>
                    Learn More
                    <ArrowRight size={16} aria-hidden="true" />
                  </a>
                </div>
              </article>
            )
          })}
        </div>
      </div>
    </section>
  )
}

export default Services
