"use client"

import { useState, useEffect } from "react"
import { Link } from "react-scroll"
import { Menu, X, Smile } from "lucide-react"
import styles from "./Header.module.css"

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const navItems = [
    { name: "Home", to: "hero" },
    { name: "Services", to: "services" },
    { name: "Team", to: "team" },
    { name: "Testimonials", to: "testimonials" },
    { name: "Contact", to: "contact" },
  ]

  return (
    <header className={`${styles.header} ${isScrolled ? styles.headerScrolled : ""}`}>
      <div className="container">
        <nav className={styles.nav} role="navigation" aria-label="Main navigation">
          <Link
            to="hero"
            smooth={true}
            duration={500}
            className={styles.logo}
            aria-label="Miami Beach Smiles - Go to homepage"
          >
            <Smile className={styles.logoIcon} aria-hidden="true" />
            <span>Miami Beach Smiles</span>
          </Link>

          <ul className={styles.navLinks}>
            {navItems.map((item) => (
              <li key={item.name}>
                <Link
                  to={item.to}
                  smooth={true}
                  duration={500}
                  offset={-80}
                  className={styles.navLink}
                  activeClass={styles.active}
                  spy={true}
                >
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>

          <Link to="contact" smooth={true} duration={500} offset={-80} className={styles.ctaButton}>
            Schedule Now
          </Link>

          <button
            className={styles.mobileMenuButton}
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle mobile menu"
            aria-expanded={isMobileMenuOpen}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </nav>

        <div className={`${styles.mobileMenu} ${isMobileMenuOpen ? styles.open : ""}`}>
          <ul className={styles.mobileNavLinks}>
            {navItems.map((item) => (
              <li key={item.name}>
                <Link
                  to={item.to}
                  smooth={true}
                  duration={500}
                  offset={-80}
                  className={styles.navLink}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.name}
                </Link>
              </li>
            ))}
            <li>
              <Link
                to="contact"
                smooth={true}
                duration={500}
                offset={-80}
                className={styles.ctaButton}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Schedule Now
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </header>
  )
}

export default Header
