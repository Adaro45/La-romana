import { Star } from "lucide-react"
import styles from "./Testimonials.module.css"

const Testimonials = () => {
  const testimonials = [
    {
      id: 1,
      text: "Dr. Gaertner and his team transformed my smile completely! The Invisalign treatment was comfortable and the results exceeded my expectations. I couldn't be happier with my new smile.",
      author: "Sarah Martinez",
      role: "Marketing Executive",
      image: "/placeholder.svg?height=60&width=60",
      rating: 5,
    },
    {
      id: 2,
      text: "The level of care and professionalism at Miami Beach Smiles is outstanding. From the moment I walked in, I felt comfortable and well-cared for. The dental implant procedure was seamless.",
      author: "Michael Thompson",
      role: "Business Owner",
      image: "/placeholder.svg?height=60&width=60",
      rating: 5,
    },
    {
      id: 3,
      text: "I was nervous about getting veneers, but Dr. Johnson made the entire process easy and stress-free. My smile looks natural and beautiful. I recommend this practice to everyone!",
      author: "Emily Rodriguez",
      role: "Teacher",
      image: "/placeholder.svg?height=60&width=60",
      rating: 5,
    },
  ]

  const beforeAfterImages = [
    {
      id: 1,
      before: "/placeholder.svg?height=200&width=300",
      after: "/placeholder.svg?height=200&width=300",
      treatment: "Smile Makeover",
    },
    {
      id: 2,
      before: "/placeholder.svg?height=200&width=300",
      after: "/placeholder.svg?height=200&width=300",
      treatment: "Teeth Whitening",
    },
  ]

  return (
    <section id="testimonials" className={styles.testimonials}>
      <div className="container">
        <div className={styles.testimonialsHeader}>
          <p className={styles.testimonialsSubtitle}>Patient Reviews</p>
          <h2 className={styles.testimonialsTitle}>
            What Our Patients
            <br />
            Are Saying
          </h2>
          <p className={styles.testimonialsDescription}>
            Don't just take our word for it. Here's what our satisfied patients have to say about their experience at
            Miami Beach Smiles.
          </p>
        </div>

        <div className={styles.testimonialsGrid}>
          {testimonials.map((testimonial) => (
            <article key={testimonial.id} className={styles.testimonialCard}>
              <p className={styles.testimonialText}>{testimonial.text}</p>
              <div className={styles.testimonialAuthor}>
                <img
                  src={testimonial.image || "/placeholder.svg"}
                  alt={`Portrait of ${testimonial.author}`}
                  className={styles.authorImage}
                  loading="lazy"
                />
                <div className={styles.authorInfo}>
                  <h4>{testimonial.author}</h4>
                  <p>{testimonial.role}</p>
                  <div className={styles.rating}>
                    {[...Array(testimonial.rating)].map((_, index) => (
                      <Star key={index} className={styles.star} size={16} fill="currentColor" />
                    ))}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>

        <div className={styles.beforeAfter}>
          <h3 className={styles.beforeAfterTitle}>Our Smile Makeover Results</h3>
          <div className={styles.beforeAfterGrid}>
            {beforeAfterImages.map((item) => (
              <div key={item.id} className={styles.beforeAfterCard}>
                <div style={{ display: "flex" }}>
                  <div style={{ flex: 1 }}>
                    <img
                      src={item.before || "/placeholder.svg"}
                      alt={`Before ${item.treatment} treatment`}
                      className={styles.beforeAfterImage}
                      loading="lazy"
                    />
                    <div className={styles.beforeAfterLabel}>Before</div>
                  </div>
                  <div style={{ flex: 1 }}>
                    <img
                      src={item.after || "/placeholder.svg"}
                      alt={`After ${item.treatment} treatment`}
                      className={styles.beforeAfterImage}
                      loading="lazy"
                    />
                    <div className={styles.beforeAfterLabel}>After</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}

export default Testimonials
