"use client"

import { useState } from "react"
import { MapPin, Phone, Mail, Clock } from "lucide-react"
import styles from "./Contact.module.css"

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: "",
  })

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // Handle form submission here
    console.log("Form submitted:", formData)
    alert("Thank you for your message! We will contact you soon.")
    setFormData({
      name: "",
      email: "",
      phone: "",
      service: "",
      message: "",
    })
  }

  const hours = [
    { day: "Monday", time: "8:30 AM - 5:00 PM" },
    { day: "Tuesday", time: "8:30 AM - 6:00 PM" },
    { day: "Wednesday", time: "8:30 AM - 6:00 PM" },
    { day: "Thursday", time: "8:30 AM - 5:00 PM" },
    { day: "Friday", time: "8:30 AM - 2:00 PM" },
  ]

  return (
    <section id="contact" className={styles.contact}>
      <div className="container">
        <div className={styles.contactHeader}>
          <p className={styles.contactSubtitle}>Contact Us</p>
          <h2 className={styles.contactTitle}>
            Schedule Your Visit
            <br />
            Today
          </h2>
          <p className={styles.contactDescription}>
            Ready to transform your smile? Contact us today to schedule your consultation and take the first step
            towards optimal oral health.
          </p>
        </div>

        <div className={styles.contactContent}>
          <div className={styles.contactInfo}>
            <div className={styles.infoCard}>
              <MapPin className={styles.infoIcon} aria-hidden="true" />
              <div className={styles.infoContent}>
                <h3>Location</h3>
                <p>
                  1688 Meridian Ave, Suite 414
                  <br />
                  Miami Beach, FL 33139
                </p>
              </div>
            </div>

            <div className={styles.infoCard}>
              <Phone className={styles.infoIcon} aria-hidden="true" />
              <div className={styles.infoContent}>
                <h3>Phone</h3>
                <p>
                  <a href="tel:(305)534-2526" aria-label="Call us at (305) 534-2526">
                    (305) 534-2526
                  </a>
                </p>
              </div>
            </div>

            <div className={styles.infoCard}>
              <Mail className={styles.infoIcon} aria-hidden="true" />
              <div className={styles.infoContent}>
                <h3>Email</h3>
                <p>
                  <a href="mailto:info@miamibeachsmiles.com">info@miamibeachsmiles.com</a>
                </p>
              </div>
            </div>

            <div className={styles.infoCard}>
              <Clock className={styles.infoIcon} aria-hidden="true" />
              <div className={styles.infoContent}>
                <h3>Office Hours</h3>
                <div className={styles.hoursGrid}>
                  {hours.map((hour, index) => (
                    <div key={index}>
                      <span>{hour.day}:</span>
                      <span>{hour.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <form className={styles.contactForm} onSubmit={handleSubmit}>
            <div className={styles.formGroup}>
              <label htmlFor="name">Full Name *</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                aria-required="true"
              />
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="email">Email Address *</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                aria-required="true"
              />
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="phone">Phone Number</label>
              <input type="tel" id="phone" name="phone" value={formData.phone} onChange={handleChange} />
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="service">Service of Interest</label>
              <select id="service" name="service" value={formData.service} onChange={handleChange}>
                <option value="">Select a service</option>
                <option value="general">General Dentistry</option>
                <option value="cosmetic">Cosmetic Dentistry</option>
                <option value="restorative">Restorative Dentistry</option>
                <option value="invisalign">Invisalign</option>
                <option value="emergency">Emergency Care</option>
              </select>
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="message">Message</label>
              <textarea
                id="message"
                name="message"
                value={formData.message}
                onChange={handleChange}
                placeholder="Tell us about your dental needs or questions..."
              />
            </div>

            <button type="submit" className={styles.submitButton}>
              Schedule Appointment
            </button>
          </form>
        </div>

        <div className={styles.mapContainer}>
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3592.8!2d-80.1389!3d25.7907!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88d9b4a9d77ac6cd%3A0x24c0c4c4c4c4c4c4!2s1688%20Meridian%20Ave%2C%20Miami%20Beach%2C%20FL%2033139!5e0!3m2!1sen!2sus!4v1234567890"
            className={styles.map}
            allowFullScreen=""
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Miami Beach Smiles Location"
          />
        </div>
      </div>
    </section>
  )
}

export default Contact
