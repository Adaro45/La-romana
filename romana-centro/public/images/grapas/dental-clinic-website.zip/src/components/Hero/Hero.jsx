import { Link } from "react-scroll"
import { Calendar, Phone } from "lucide-react"
import styles from "./Hero.module.css"

const Hero = () => {
  return (
    <section id="hero" className={styles.hero}>
      <div className="container">
        <div className={styles.heroContent}>
          <p className={styles.heroSubtitle}>Miami Beach Smiles</p>
          <h1 className={styles.heroTitle}>
            Miami Beach's
            <br />
            Dental Experts
          </h1>
          <p className={styles.heroDescription}>
            Experience the gold standard for modern, premium dental care. We provide beautiful, sparkling, and confident
            smiles in a cutting-edge office with the latest technology and personalized treatment plans.
          </p>
          <div className={styles.heroButtons}>
            <Link
              to="contact"
              smooth={true}
              duration={500}
              offset={-80}
              className={styles.primaryButton}
              aria-label="Book an appointment"
            >
              <Calendar size={20} aria-hidden="true" />
              Book an Appointment
            </Link>
            <a href="tel:(305)534-2526" className={styles.secondaryButton} aria-label="Call us at (305) 534-2526">
              <Phone size={20} aria-hidden="true" />
              (305) 534-2526
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Hero
